#include "stage_visual.h"

#include <cstring>
#include <limits>
#include <stdexcept>

namespace jsrf {
namespace {

void requireRange(std::span<const std::byte> bytes, std::size_t off, std::size_t count, const char* what) {
    if (off > bytes.size() || count > bytes.size() - off) {
        throw std::runtime_error(std::string("truncated Stage_Model ") + what);
    }
}

std::uint32_t u32(std::span<const std::byte> bytes, std::size_t off) {
    requireRange(bytes, off, 4u, "uint32");
    std::uint32_t v{};
    std::memcpy(&v, bytes.data() + off, 4u);
    return v;
}

std::int32_t i32(std::span<const std::byte> bytes, std::size_t off) {
    return static_cast<std::int32_t>(u32(bytes, off));
}

std::uint16_t u16(std::span<const std::byte> bytes, std::size_t off) {
    requireRange(bytes, off, 2u, "uint16");
    std::uint16_t v{};
    std::memcpy(&v, bytes.data() + off, 2u);
    return v;
}

float f32(std::span<const std::byte> bytes, std::size_t off) {
    requireRange(bytes, off, 4u, "float");
    float v{};
    std::memcpy(&v, bytes.data() + off, 4u);
    return v;
}

Vec3 vec3(std::span<const std::byte> bytes, std::size_t off) {
    return {f32(bytes, off), f32(bytes, off + 4u), f32(bytes, off + 8u)};
}

std::size_t modelHeaderOffset(std::span<const std::byte> itemBytes) {
    requireRange(itemBytes, 0, 4u, "texture-id count");
    const std::uint32_t textureCount = u32(itemBytes, 0);
    if (textureCount == 0u || textureCount > 1'000'000u) {
        throw std::runtime_error("invalid Stage_Model texture-id count");
    }
    const std::uint64_t offset64 = 4u + static_cast<std::uint64_t>(textureCount) * 4u;
    if (offset64 > itemBytes.size()) throw std::runtime_error("Stage_Model texture-id list extends outside record");
    return static_cast<std::size_t>(offset64);
}

}  // namespace

bool isIndexedStageMdlb(std::span<const std::byte> itemBytes) noexcept {
    try {
        const std::size_t off = modelHeaderOffset(itemBytes);
        return off + 4u <= itemBytes.size() &&
               itemBytes[off + 0u] == std::byte{'M'} &&
               itemBytes[off + 1u] == std::byte{'D'} &&
               itemBytes[off + 2u] == std::byte{'L'} &&
               itemBytes[off + 3u] == std::byte{'B'};
    } catch (...) {
        return false;
    }
}

StageVisualMesh decodeStageVisualMesh(std::span<const std::byte> itemBytes) {
    const std::uint32_t textureCount = u32(itemBytes, 0);
    const std::size_t headerOff = modelHeaderOffset(itemBytes);
    if (isIndexedStageMdlb(itemBytes)) throw std::runtime_error("indexed record contains MDLB rather than Stage_Model");
    requireRange(itemBytes, headerOff, 144u, "header");

    StageVisualMesh out;
    out.textureIds.reserve(textureCount);
    for (std::uint32_t i = 0; i < textureCount; ++i) out.textureIds.push_back(u32(itemBytes, 4u + i * 4u));

    out.center = vec3(itemBytes, headerOff + 32u);
    out.radius = f32(itemBytes, headerOff + 44u);
    const std::int32_t materialCountSigned = i32(itemBytes, headerOff + 124u);
    const std::int32_t materialGroupCountSigned = i32(itemBytes, headerOff + 132u);
    if (materialCountSigned < 0 || materialGroupCountSigned < 0 || materialGroupCountSigned > 1'000'000) {
        throw std::runtime_error("invalid Stage_Model material counts");
    }
    const std::uint32_t materialCount = static_cast<std::uint32_t>(materialCountSigned);
    const std::uint32_t materialGroupCount = static_cast<std::uint32_t>(materialGroupCountSigned);

    std::size_t off = headerOff + 144u;
    const std::uint64_t materialsBytes = static_cast<std::uint64_t>(materialCount) * 20u;
    if (materialsBytes > std::numeric_limits<std::size_t>::max()) throw std::runtime_error("Stage_Model material list is too large");
    requireRange(itemBytes, off, static_cast<std::size_t>(materialsBytes), "materials");
    off += static_cast<std::size_t>(materialsBytes);
    if (materialCount == 0u) {
        requireRange(itemBytes, off, 20u, "zero-material padding");
        off += 20u;
    }

    requireRange(itemBytes, off, 32u, "vertex/index header");
    const std::uint32_t lastMaterialGroupBboxOffset = u32(itemBytes, off + 0u);
    const std::uint32_t vertexCount = u32(itemBytes, off + 4u);
    out.vertexFormat = u32(itemBytes, off + 8u);
    out.vertexStride = u32(itemBytes, off + 12u);
    const std::uint32_t vertexBufferSize = u32(itemBytes, off + 16u);
    const std::uint32_t indexCount = u32(itemBytes, off + 20u);
    out.triangleStrip = u32(itemBytes, off + 24u) != 0u;
    if (vertexCount == 0u || vertexCount > 1'000'000u || out.vertexStride < 12u || out.vertexStride > 256u) {
        throw std::runtime_error("invalid Stage_Model vertex layout");
    }
    if (vertexBufferSize < lastMaterialGroupBboxOffset) throw std::runtime_error("Stage_Model vertex buffer size underflows bbox prefix");
    const std::uint64_t expectedVertexBytes = static_cast<std::uint64_t>(vertexCount) * out.vertexStride;
    const std::uint64_t decodedVertexBytes = static_cast<std::uint64_t>(vertexBufferSize) - lastMaterialGroupBboxOffset;
    if (decodedVertexBytes != expectedVertexBytes) throw std::runtime_error("Stage_Model vertex buffer byte count does not match vertex count/stride");
    off += 32u;

    out.materialGroups.reserve(materialGroupCount);
    requireRange(itemBytes, off, static_cast<std::size_t>(materialGroupCount) * 32u, "material groups");
    for (std::uint32_t i = 0; i < materialGroupCount; ++i) {
        const std::size_t g = off + static_cast<std::size_t>(i) * 32u;
        const std::int32_t triangleCount = i32(itemBytes, g + 0u);
        const std::int32_t triangleStart = i32(itemBytes, g + 4u);
        const std::int32_t materialIndex = i32(itemBytes, g + 12u);
        if (triangleCount < 0 || triangleStart < 0 || materialIndex < 0) throw std::runtime_error("negative Stage_Model material-group field");
        out.materialGroups.push_back({
            static_cast<std::uint32_t>(triangleCount),
            static_cast<std::uint32_t>(triangleStart),
            static_cast<std::uint32_t>(materialIndex)});
    }
    off += static_cast<std::size_t>(materialGroupCount) * 32u;

    requireRange(itemBytes, off, static_cast<std::size_t>(materialGroupCount) * 16u, "material-group bounds");
    off += static_cast<std::size_t>(materialGroupCount) * 16u;

    const std::size_t vertexBytes = static_cast<std::size_t>(decodedVertexBytes);
    requireRange(itemBytes, off, vertexBytes, "vertices");
    out.vertices.reserve(vertexCount);
    for (std::uint32_t i = 0; i < vertexCount; ++i) {
        const std::size_t v = off + static_cast<std::size_t>(i) * out.vertexStride;
        StageVisualVertex decoded;
        decoded.position = vec3(itemBytes, v);
        if (out.vertexStride == 32u) {
            decoded.normal = vec3(itemBytes, v + 12u);
            decoded.texcoord = {f32(itemBytes, v + 24u), f32(itemBytes, v + 28u)};
            decoded.hasNormal = true;
            decoded.hasTexcoord = true;
        } else if (out.vertexStride == 28u) {
            decoded.texcoord = {f32(itemBytes, v + 12u), 1.0f - f32(itemBytes, v + 16u)};
            decoded.hasTexcoord = true;
        } else if (out.vertexStride == 24u) {
            decoded.texcoord = {f32(itemBytes, v + 16u), f32(itemBytes, v + 20u)};
            decoded.hasTexcoord = true;
        } else if (out.vertexStride == 36u) {
            decoded.texcoord = {f32(itemBytes, v + 20u), f32(itemBytes, v + 24u)};
            decoded.hasTexcoord = true;
        }
        out.vertices.push_back(decoded);
    }
    off += vertexBytes;

    requireRange(itemBytes, off, static_cast<std::size_t>(indexCount) * 2u, "triangle indices");
    auto indexAt = [&](std::uint32_t i) -> std::uint16_t {
        const auto value = u16(itemBytes, off + static_cast<std::size_t>(i) * 2u);
        if (value >= vertexCount) throw std::runtime_error("Stage_Model triangle index exceeds vertex count");
        return value;
    };

    if (!out.triangleStrip) {
        if (indexCount % 3u != 0u) throw std::runtime_error("Stage_Model list index count is not divisible by three");
        out.triangles.reserve(indexCount / 3u);
        for (std::uint32_t i = 0; i < indexCount; i += 3u) {
            out.triangles.push_back({indexAt(i), indexAt(i + 1u), indexAt(i + 2u)});
        }
    } else {
        // Retail Stage_Model strips use degenerate indices as strip separators.
        // The ModTool reference parser removes the two connector triangles that
        // can remain around particular one-index separator patterns; simply
        // dropping degenerate triangles leaves giant cross-stage polygons.
        if (indexCount >= 3u) out.triangles.reserve(indexCount - 2u);
        bool invalid = false;
        bool previousInvalid = false;
        int previousValidCount = 0;
        int currentValidCount = 0;
        int previousInvalidCount = 0;
        bool plusOne = false;
        int invalidCount = 0;

        for (std::uint32_t i = 0; i + 2u < indexCount; ++i) {
            const std::uint16_t a = indexAt(i);
            const std::uint16_t b = indexAt(i + 1u);
            const std::uint16_t c = indexAt(i + 2u);
            const bool degenerate = a == b || a == c || b == c;

            if (degenerate) {
                if (!previousInvalid) {
                    if (currentValidCount == 6 && previousInvalidCount == 1 &&
                        (currentValidCount - previousValidCount) > 2) {
                        if (plusOne && currentValidCount - 1 > 5) {
                            const int removeAt = static_cast<int>(out.triangles.size()) -
                                std::abs(currentValidCount - previousValidCount);
                            if (removeAt >= 0 && static_cast<std::size_t>(removeAt + 2) <= out.triangles.size())
                                out.triangles.erase(out.triangles.begin() + removeAt,
                                                    out.triangles.begin() + removeAt + 2);
                        }
                    }
                    if (currentValidCount > 6 &&
                        (currentValidCount - previousValidCount) > 2) {
                        plusOne = false;
                        const int removeAt = static_cast<int>(out.triangles.size()) -
                            std::abs(currentValidCount - previousValidCount);
                        if (removeAt >= 0 && static_cast<std::size_t>(removeAt + 2) <= out.triangles.size())
                            out.triangles.erase(out.triangles.begin() + removeAt,
                                                out.triangles.begin() + removeAt + 2);
                    }
                }
                invalid = true;
                previousInvalid = true;
                ++invalidCount;
            } else {
                if (previousInvalid) {
                    previousInvalid = false;
                    previousInvalidCount = invalidCount;
                    previousValidCount = currentValidCount;
                    currentValidCount = 0;
                    if (previousInvalidCount == 1 && previousValidCount == 1) {
                        plusOne = true;
                        ++currentValidCount;
                    }
                    invalidCount = 0;
                }
                invalid = false;
                ++currentValidCount;
            }

            if (!invalid) {
                if ((i & 1u) == 0u) out.triangles.push_back({a, b, c});
                else out.triangles.push_back({c, b, a});
            }
        }
    }

    return out;
}

}  // namespace jsrf
