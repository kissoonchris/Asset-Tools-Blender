#pragma once

#include "mdlb_mesh.h"

#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

namespace jsrf {

struct StageVisualVertex {
    Vec3 position{};
    Vec3 normal{};
    Vec2 texcoord{};
    bool hasNormal{};
    bool hasTexcoord{};
};

struct StageVisualMaterialGroup {
    std::uint32_t triangleCount{};
    std::uint32_t triangleStartIndex{};
    std::uint32_t materialIndex{};
};

struct StageVisualMesh {
    std::vector<std::uint32_t> textureIds;
    std::vector<StageVisualVertex> vertices;
    std::vector<Triangle> triangles;
    std::vector<StageVisualMaterialGroup> materialGroups;
    Vec3 center{};
    float radius{};
    std::uint32_t vertexFormat{};
    std::uint32_t vertexStride{};
    bool triangleStrip{};
};

[[nodiscard]] bool isIndexedStageMdlb(std::span<const std::byte> itemBytes) noexcept;
[[nodiscard]] StageVisualMesh decodeStageVisualMesh(std::span<const std::byte> itemBytes);

}  // namespace jsrf
