#include "stage_textures.h"

#include "asset_container.h"
#include "binary_file.h"
#include "texture_asset.h"

#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <string>

namespace jsrf {
namespace {
std::uint32_t u32(std::span<const std::byte> bytes, std::size_t off) {
    if (off + 4u > bytes.size()) throw std::runtime_error("truncated indexed stage texture header");
    std::uint32_t out{};
    std::memcpy(&out, bytes.data() + off, sizeof(out));
    return out;
}
}

StageTextureSet loadRetailStageTextures(
    const std::filesystem::path& mediaRoot,
    std::string_view stageStem) {
    StageTextureSet out;
    for (int chunk = 1; chunk <= 4; ++chunk) {
        const std::string filename = std::string(stageStem) + "_0" + std::to_string(chunk) + ".dat";
        const auto bytes = readBinaryFile(mediaRoot / "Stage" / filename);
        const auto indexed = parseAssetContainer(bytes);
        for (const auto& item : indexed.items) {
            if (item.bytes.size() < 32u) continue;
            const std::uint32_t id = u32(item.bytes, 0u);
            const std::uint32_t format = u32(item.bytes, 0x18u);
            if (format == 0x00000505u) {
                const auto texture = parseVerifiedBc1Texture(item.bytes);
                out.bc1[id] = decodeBc1(texture.topMip, texture.width, texture.height);
            } else {
                if (std::find(out.unsupportedIds.begin(), out.unsupportedIds.end(), id) == out.unsupportedIds.end()) {
                    out.unsupportedIds.push_back(id);
                }
            }
        }
    }
    std::sort(out.unsupportedIds.begin(), out.unsupportedIds.end());
    return out;
}

} // namespace jsrf
