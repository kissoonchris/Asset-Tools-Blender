#pragma once

#include "bc1_texture.h"

#include <cstdint>
#include <filesystem>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace jsrf {

struct StageTextureSet {
    std::unordered_map<std::uint32_t, RgbaImage> bc1;
    std::vector<std::uint32_t> unsupportedIds;
};

[[nodiscard]] StageTextureSet loadRetailStageTextures(
    const std::filesystem::path& mediaRoot,
    std::string_view stageStem);

} // namespace jsrf
