JSRF Native checkpoint 03 — repaired source payload

The original checkpoint-03 ZIP uploaded to GitHub was truncated before the ZIP central directory.
This replacement is a valid recovery package containing the checkpoint-03 Garage visual/texture decoder source preserved in the current working tree.

These files are intended to be overlaid on checkpoint 02 source:
  src/stage_visual.cpp
  src/stage_visual.h
  src/stage_textures.cpp
  src/stage_textures.h

The current JSRF source has moved beyond checkpoint 03; later collision/grind integration is backed up separately.
No retail Media files or default.xbe are included.
